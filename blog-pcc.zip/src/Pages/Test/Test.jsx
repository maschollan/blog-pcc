// Library
import React, {useEffect, useState} from "react";
import { Link } from "react-router-dom";

// Components
import Layout from "../../Components/Layout";

// Api
import useAxios from "../../utils/useAxios";
import GetDataError from "../../Components/GetDataError";
import GetDataLoading from "../../Components/GetDataLoading";
import { removeContent, getAllContents } from "../../Pages/Test/httpService";

const Test = () => {

  const {  isLoading, isError } = useAxios(
    `http://localhost:3000/posts?featurjjed=true`
  );

  // const [ terhapus, setTerhapus ] = useState(false);
  const [ rows, setRows ] = useState([]);
  const [ isRowChanged, setIsRowChanged ] = useState(false);

  useEffect(() => {
        getAllContents().then(res => setRows(res.data));
    });

    useEffect(() => {
        if (isRowChanged) {
            getAllContents().then(res => setRows(res.data));
        }
        setIsRowChanged();
    }, [isRowChanged]);

  const hapus = (id) => {
    removeContent(id).then(() => {
      alert("success");
      setIsRowChanged(true);
    });
  };

  // Loading Fetch Data
  if (isLoading)
    return (
      <Layout>
        <GetDataLoading />
      </Layout>
    );

  // Error While Fetching Data
  if (isError)
    return (
      <Layout>
        <GetDataError error={isError} />
      </Layout>
    );

  return (
    <div className={`bg-gray-800 font-patrick flex justify-center items-center w-screen min-h-screen absolute top-0 left-0 overflow-hidden`}>
      <div className="container mx-auto text-bold text-center tracking-wider">
      <Link className="text-xl transition-all mt-3 hover:text-gray-500 cursor-pointer" to={`/create`}>
        Tambah
      </Link> 
        <table className="text-white border border-indigo-600 border-collapse">
          <thead>
            <tr>
              <th className="border border-indigo-600">id</th>
              <th className="border border-indigo-600">title</th>
              <th className="border border-indigo-600">nama</th>
              <th className="border border-indigo-600">head</th>
              <th className="border border-indigo-600">action</th>
            </tr>
          </thead>
          {rows.map((post) => {
            return (
            <tbody>
              <tr>
                <td className="border border-indigo-600">{post.id}</td>
                <td className="border border-indigo-600">{post.title}</td>
                <td className="border border-indigo-600">{post.author.name}</td>
                <td className="border border-indigo-600">{post.headline}</td>
                <td className="border border-indigo-600">
                  <Link className="text-xl transition-all mt-3 hover:text-gray-500 cursor-pointer" to={`/edit/${post.id}`}>
                    Edit
                  </Link> 
                  <p className="text-xl transition-all mt-3 hover:text-gray-500 cursor-pointer" onClick={() => hapus(post.id)}>
                    Delete
                  </p>
                </td>
              </tr>
            </tbody>
            );
          })}
        </table>
      </div>
    </div>
  );
};
export default Test