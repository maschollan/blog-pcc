// Library
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useHistory } from "react-router-dom";


// Components
import Layout from "../../Components/Layout";
import GetDataError from "../../Components/GetDataError";
import GetDataLoading from "../../Components/GetDataLoading";
import NotFound from "../404/notFound";
import Test from "./Test";
import { createContent } from "./httpService";
import useAxios from "../../utils/useAxios";


const Create = () => {

  const { posts, isLoading, isError } = useAxios(`http://localhost:3000/posts?id=1`, 'Blog PCC');

  const post = posts[0];

  const { register, formState: { errors }, handleSubmit, setValue, getValues
  } = useForm({
    mode: "onChange"
  });

  const [redirect, setRedirect] = useState(false);
  const history = useHistory();

  const onSubmit = (data) => {
    createContent(data).then(() => {
      setRedirect(true);
      history.push("/test")
    });
  };

  const updatedAt = () => {
    setValue('updated_at', new Date().toISOString());
  };

  // const [title, setTitle] = useState("");
  // const [headline, setHeadline] = useState("");
  // const [contents, setContents] = useState("");

  // function setHandleTitle(e) {
  //   setTitle(e.target.value)
  // }

  // function setHandleHeadline(e) {
  //   setTitle(e.target.value)
  // }

  // function setHandleContents(e) {
  //   setTitle(e.target.value)
  // }


  useEffect(() => {
    if (!redirect) {
      setValue('title', "");
      setValue('slug', "");
      setValue('featured', false);
      setValue('headline', "");
      setValue('publised_at', new Date().toISOString())
      setValue('created_at', new Date().toISOString())
      setValue('updated_at', new Date().toISOString())
      setValue('category.id', post !== undefined ? post.category.id : "");
      setValue('category.name', post !== undefined ? post.category.name : "");
      setValue('category.slug', post !== undefined ? post.category.slug : "");
      setValue('author.id', post !== undefined ? post.author.id : "");
      setValue('author.name', post !== undefined ? post.author.name : "");
      setValue('author.avatar.id', post !== undefined ? post.author.avatar.id : "");
      setValue('author.avatar.name', post !== undefined ? post.author.avatar.name : "");
      setValue('contents', "");
      setValue('thumbnail.id', post !== undefined ? post.thumbnail.id : "");
      setValue('thumbnail.name', post !== undefined ? post.thumbnail.name : "");
    }
  });


  // Loading Fetch Data
  if (isLoading)
    return (
      <Layout>
        <GetDataLoading />
      </Layout>
    );

  // Error While Fetching Data
  if (isError)
    return (
      <Layout>
        <GetDataError error={isError} />
      </Layout>
    );

  if (typeof post === 'undefined')
    return (
      <NotFound />
    );

  if (redirect) return (
    <Test />
  );

  return (
    <Layout>
      <div className="w-full flex justify-center mx-auto py-2">
        <div className="w-full flex justify-center">
          <form onSubmit={handleSubmit(onSubmit)} className="bg-white w-full shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Title
              </label>
              <input {...register("title", { required: true })} onChange={() => {
                setValue('slug', getValues("title").replace(/\W+/g, '-').toLowerCase());
              }}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" placeholder="title" />
              {/* <Controller as={<input type="text" />} name="title" control={control} defaultValue="" /> */}
              {errors.title && <p className="text-red-500 text-xs italic">Please choose a password.</p>}
            </div>
            <div className="mb-6">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Headline
              </label>
              <input {...register("headline", { required: true })} onChange={updatedAt()}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" placeholder="headline" />
              {errors.headline && <p className="text-red-500 text-xs italic">Please choose a password.</p>}
            </div>
            <div className="mb-6">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Contents
              </label>
              <textarea {...register("contents", { required: true })} onChange={updatedAt()}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" rows="10" placeholder="content" />
              {errors.contents && <p className="text-red-500 text-xs italic">Please choose a password.</p>}
            </div>
            <div className="flex items-center justify-between">
              <input className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="submit" value="edit" />
            </div>
          </form>
        </div>

        {/*<div className="w-full md:w-6/12 flex justify-center">
          <div className="bg-white text-gray-700 w-full shadow-md rounded px-8 py-8 mb-4 overflow-y-scroll">
            <h2 className="text-2xl lg:text-3xl text-center">
              {title}
            </h2>
            <p className="text-lg mb-4">
              {headline}
            </p>
            <ReactMarkdown className="prose text-gray-700">
              {contents}
            </ReactMarkdown>
          </div>
        </div>*/}
      </div>
    </Layout>
  );
};

export default Create;
