# UI BLOG  PCC

## Setup
1. Download Zip/Clone repository
2. Buka App di text editor
3. Buka terminal dan arahkan ke folder blog-pcc
4. Jalankan perintah `npm install` untuk menginstall semua dependencies
5. jalankan json-server dengan perintah `json-server --watch db.json`
6. jalankan perintah `npm start` untuk menjalankan Aplikasinya di mode development
7. Buka https://localhost:3000 untuk melihat hasil aplikasi webnya

#### Happy Coding:)